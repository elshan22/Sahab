package com.example.ruleevaluator.model;

import lombok.Data;

@Data
public class Rule {
    private String name;
    private String type;
    private String message;
}
