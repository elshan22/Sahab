package com.example.ruleevaluator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RuleEvaluatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(RuleEvaluatorApplication.class, args);
	}

}
